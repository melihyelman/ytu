int main()
{
int _aa, _bb, _cc;
char _aa;
char _x;
_aa = 5;
_xx = 9;
_bb = _aa + _dd;
}