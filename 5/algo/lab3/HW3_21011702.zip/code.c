int main()
{
int _aa, _bb, _cc;
char _aa;
char _x;
_aa = 5;
_xx = 9;
_bb = _aa + _dd;
if(_123 == 5) {
    while(_ab < 10) {
        _aa = _aa + 1;
    }
    for(int _i = 0; _i < 10; _i++) {
        _j = _bb + 1;
    }
}
}