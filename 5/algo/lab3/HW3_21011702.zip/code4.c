int main()
{
int _aa, _bb, _cc;
char _aa;
float _x = 10;
_aa = 5;
_xx = 9;
_bb = _aa + _dd;
if(_xx == 9) {
    _d = _aa + 1;
}else {
    int _ff = 10;
}

for(int _i = 0; _i < 10; i++) {
    _j = _bb + 1;
}

while(_ab < 10) {
    _aa = _aa + 1;
}

int _ab, _cd, _ef;
char _gh;

_ab = 5;
_cdf = 10;

}